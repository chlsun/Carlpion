package com.kh.carlpion.exception.exceptions;

public class FileDeleteException extends RuntimeException {
	
	public FileDeleteException(String message) {
		super(message);
	}
}
