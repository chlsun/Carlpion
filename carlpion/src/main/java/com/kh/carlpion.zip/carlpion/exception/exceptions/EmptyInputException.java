package com.kh.carlpion.exception.exceptions;

public class EmptyInputException extends RuntimeException {
	public EmptyInputException(String message) {
		super(message);
	}
}
