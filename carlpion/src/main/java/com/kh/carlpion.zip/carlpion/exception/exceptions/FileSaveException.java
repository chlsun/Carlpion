package com.kh.carlpion.exception.exceptions;

public class FileSaveException extends RuntimeException {
	
	public FileSaveException(String message) {
		super(message);
	}
}
