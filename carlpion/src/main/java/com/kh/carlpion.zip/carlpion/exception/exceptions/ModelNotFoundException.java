package com.kh.carlpion.exception.exceptions;

public class ModelNotFoundException extends RuntimeException{
	public ModelNotFoundException(String message) {
		super(message);
	}
}
