package com.kh.carlpion.exception.exceptions;

public class NotFindException extends RuntimeException {
	
	public NotFindException(String message) {
		super(message);
	}

}
