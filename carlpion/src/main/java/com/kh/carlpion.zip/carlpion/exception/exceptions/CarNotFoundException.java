package com.kh.carlpion.exception.exceptions;

public class CarNotFoundException extends RuntimeException{
	public CarNotFoundException(String message) {
		super(message);
	}
}
