package com.kh.carlpion.exception.exceptions;

public class UnauthorizedException extends RuntimeException {
	
	public UnauthorizedException(String message) {
		super(message);
	}
}
