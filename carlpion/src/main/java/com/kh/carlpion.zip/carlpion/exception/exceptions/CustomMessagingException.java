package com.kh.carlpion.exception.exceptions;

public class CustomMessagingException extends RuntimeException {

	private static final long serialVersionUID = 4048558136037067274L;

	public CustomMessagingException(String msg) {
		
		super(msg);
	}
}
