package com.kh.carlpion.user.model.service;

import com.kh.carlpion.user.model.dto.UserDTO;

public interface UserService {

	void signUp(UserDTO user);
}
