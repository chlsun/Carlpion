package com.kh.carlpion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarlpionApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarlpionApplication.class, args);
	}

}
