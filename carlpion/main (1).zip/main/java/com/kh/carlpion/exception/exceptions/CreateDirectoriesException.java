package com.kh.carlpion.exception.exceptions;

public class CreateDirectoriesException extends RuntimeException {
	
	public CreateDirectoriesException(String message) {
		super(message);
	}
}
