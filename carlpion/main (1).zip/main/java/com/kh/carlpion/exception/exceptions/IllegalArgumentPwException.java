package com.kh.carlpion.exception.exceptions;

public class IllegalArgumentPwException extends RuntimeException {

	public IllegalArgumentPwException(String message) {
		super(message);
	}
	
}
