package com.kh.carlpion.exception.exceptions;

public class ImgFileNotFoundException extends RuntimeException{
	public ImgFileNotFoundException(String message) {
		super(message);
	}
}
