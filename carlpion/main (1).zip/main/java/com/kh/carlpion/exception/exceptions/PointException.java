package com.kh.carlpion.exception.exceptions;

public class PointException extends RuntimeException {
	
	public PointException(String message) {
		super(message);
	}
}
