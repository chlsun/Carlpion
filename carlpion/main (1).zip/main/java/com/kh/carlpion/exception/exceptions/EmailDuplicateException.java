package com.kh.carlpion.exception.exceptions;

public class EmailDuplicateException extends RuntimeException {
	public EmailDuplicateException (String message) {
		super(message);
	}
	
}
