package com.kh.carlpion.exception.exceptions;

public class RentCarNotFoundException extends RuntimeException{

	public RentCarNotFoundException(String message) {
		super(message);
	}
}
