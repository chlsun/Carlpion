package com.kh.carlpion.exception.exceptions;

public class NickNameDuplicateException extends RuntimeException {
	
	public NickNameDuplicateException (String message) {
		super(message);
	}
}
