package com.kh.carlpion.board.dto;

import lombok.Data;

@Data
public class BoardDTO {

	private long boardNo;
	private String title;
	private String category;
}
